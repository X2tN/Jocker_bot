# لتنصيب السورس تحتاج في الأول تنصيب المكاتب وهذي هي في الأسفل 

# الزعيم @php_d
sudo luarocks install luasocket ; sudo luarocks install luasec ; sudo luarocks install luautf8 ; sudo luarocks install redis-lua ; sudo  luarocks remove lua-cjson2 ; sudo  luarocks remove lua-cjson ; sudo  apt-get install lua-cjson ; sudo luarocks install Lua-cURL ; sudo service redis-server start ; sudo apt-get update -y ; sudo apt-get install g++-4.7 -y c++-4.7 ; sudo apt-get install libreadline-dev -y libconfig-dev -y libssl-dev -y lua5.2 -y liblua5.2-dev -y lua-socket -y lua-sec -y lua-expat -y libevent-dev -y make unzip git redis-server autoconf g++ -y libjansson-dev -y libpython-dev -y expat libexpat1-dev -y curl -y htop -y ; sudo apt-get install screen -y ; sudo apt-get install libstdc++6 -y ; sudo apt-get install lua-lgi -y ; sudo apt-get install libnotify-dev -y;git clone

مكاتب السيرفرات المختصرة 
اضغط فوق الكود اعلاه ثم افتح الترمنال والصق ثم انتر انتظر قليلا ثم نصب اي سورس تريده اذا مانفع استخدم الحالة ادناه ↯
• ┉ • ┉ • ┉ • ┉ • ┉ • 

1- sudo  wget https://luarocks.org/releases/luarocks-2.4.3.tar.gz

﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎


2- sudo  tar zxpf luarocks-2.4.3.tar.gz
cd luarocks-2.4.3
./configure; sudo make bootstrap

﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎

3- sudo luarocks install luasocket

﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎

4- sudo luarocks install luasec

﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎

5- sudo luarocks install luautf8

﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎

6- sudo luarocks install redis-lua

﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎

7- sudo  luarocks remove lua-cjson2

﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎

8- sudo  luarocks remove lua-cjson

﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎

9- sudo  apt-get install lua-cjson

﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎

10- sudo luarocks install Lua-cURL
cd ..

﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎﹎

بعد ما تنصب المكاتب حط كليشتك ف الترمنل ونصب